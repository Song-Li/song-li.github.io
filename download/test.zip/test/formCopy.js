function getOptionStr(key) {
  return "<option value = " + key + ">" + key + "</option>";
}

function appendRow(currentId, parentId) {
  var id = $('#table_' + parentId + ' tr').length + 1;
  var thisValue = 100 - currentValue;
  var row_str = "<tr id = tr_" + parentId + '_' + id + "></tr>";
  var $curr_row = $(row_str).appendTo('#table_' + parentId);
  var currentValue = 0;
  if (currentId != "init") currentValue = $('#' + currentId).val();

  //Used for generate the first row
  var input_id = 'td_' + parentId + '_' + id;
  var thisValue = 100 - currentValue;
  row_str = '<td><input type = "text" value = "' + thisValue + '" id = "' + input_id + '" onChange = "appendRow(\'' + input_id + '\',' +  parentId + ')"></input></td>';
  $(row_str).appendTo($curr_row)

  //Used for generate the first selection
  row_str = '<td><select id = "validToYear_' + parentId + '_' + id + '">';
  for (var i = 2017;i <= 2025;++ i) {
    row_str += getOptionStr(i);
  }
  row_str += '</select></td>'; 
  $(row_str).appendTo($curr_row);

  //Used for generate the second selection
  row_str = '<td><select id = "validToWeek_' + parentId + '_' + id + '" onChange = "generateTable(' + (parentId + 1) + ');">';
  for (var i = 0;i <= 51;++ i) {
    row_str += getOptionStr(i);
  }
  row_str += '</select></td>'; 
  $(row_str).appendTo($curr_row);
}

function generateTable(id) {
  $('<table id = table_' + id + '></table>').appendTo('body');
  appendRow('init', id);
}
